
# QSSI 2026 Mathematical Foundations

## Normalization

z_ij = (x_ij - min(x_i)) /
       (max(x_i) - min(x_i))

## Entropy Weight

Objective information-content weighting.

## CRITIC Weight

Weight proportional to
standard deviation and conflict.

## PCA Weight

Weight derived from
first principal component loadings.

## Hybrid Weight

w_i = (E_i + C_i + P_i)/3

## Composite Index

QSSI_j = Σ(w_i*z_ij)

## Reliability Adjustment

RAS_j = QSSI_j * Conf_j

## Monte Carlo Validation

Repeated perturbation of
weights and rankings.

## Sensitivity Analysis

±5%
±10%
±15%

## Benchmark Validation

SCI
SCI+
SCI Ultra
