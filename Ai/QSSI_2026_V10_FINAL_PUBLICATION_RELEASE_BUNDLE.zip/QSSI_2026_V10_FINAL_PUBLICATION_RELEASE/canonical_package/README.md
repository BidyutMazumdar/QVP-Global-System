QSSI 2026 V10
CANONICAL PREDICTION PUBLICATION PACKAGE
=========================================

Author:
Bidyut Mazumdar

Independent Research Scholar
Founder, FAIR+D Canon™ — India 2025

ORCID:
https://orcid.org/0009-0007-5615-3558

DOI:
https://doi.org/10.5281/zenodo.17302169

MODEL
-----

Problem type:
REGRESSION

Target:
QSSI_SCORE

Model:
LinearRegression

Locked features:
AI_NORM, LEGAL_NORM, PQC_NORM, RES_NORM, CONFIDENCE_SCORE

Derived prediction fields:
QSSI_PREDICTED_SCORE, QSSI_PREDICTED_RANK, QSSI_PREDICTION_DELTA, QSSI_PREDICTION_ABS_ERROR

IMPORTANT SOURCE-INTEGRITY POLICY
----------------------------------

The authoritative QSSI source archive is not modified by this
package.

The authoritative source remains READ-ONLY.

The prediction outputs contained here are DERIVED and
NON-AUTHORITATIVE.

Stored QSSI_RANK and QSSI_NO_RES_RANK values remain reference
data and are not recalculated or repaired by the prediction
artifact.

NO-RES tie anomalies are preserved.

PROVENANCE
----------

Authoritative archive SHA-256:
57b264dab75ad5722e2b647ff46852bae0f5a9d239e9377e990fb3cf0b559e20

Authoritative dataset SHA-256:
4e0a12fd90f8cdfceb5367e1d399b68f6447910475e5607a7fc1d514c15d3f4c

predict.py SHA-256:
363bfe5537d98fcdea9b7927c20e817f2f5d0ef1de29afa0882bbfd5859d3137

Prediction CSV SHA-256:
b8f43a5079721465d7dfb869794925b2197778afa5fef722eeeda973b77db525

Prediction metadata SHA-256:
459fc081d0e6b88c2123114004537c151c1629381db18a0a3e96351eb1b50ef6

IP / USE POLICY
---------------

Non-commercial research use is permitted only under the
applicable research-use notice.

Commercial use, SaaS deployment, productization, commercial
distribution, enterprise deployment, or commercial derivative
use requires explicit prior written authorization/license.

Royalties, if any, are contractual and arise only when expressly
specified in a written agreement with the rights holder.

See:
license/COPYRIGHT_NOTICE.txt
license/NON_COMMERCIAL_RESEARCH_USE_NOTICE.txt
license/COMMERCIAL_SAAS_LICENSE_NOTICE.txt
license/IP_LICENSE_POLICY.json

REPRODUCIBILITY
---------------

The prediction engine reads the authoritative dataset directly
from the ZIP archive without extracting or modifying the source
archive.

The prediction artifact is derived separately.

This package includes hashes and a machine-readable manifest for
integrity verification.
