QSSI 2026 V10
FINAL PUBLICATION HANDOFF BUNDLE
================================

Author:
Bidyut Mazumdar

ORCID:
0009-0007-5615-3558

DOI:
10.5281/zenodo.17302169

Framework:
FAIR+D Canon™

STATUS
------
DERIVED / NON-AUTHORITATIVE PUBLICATION ARTIFACT

AUTHORITATIVE SOURCE
--------------------
Filename:
QSSI_2026_CLEAN_WORLD_RELEASE_ARCHIVE.zip

SHA-256:
57b264dab75ad5722e2b647ff46852bae0f5a9d239e9377e990fb3cf0b559e20

The authoritative source archive is intentionally NOT included
inside this final derived publication bundle.

It remains READ-ONLY.

DATASET
-------
QSSI_2026_MASTER_STAGE10B.csv

SHA-256:
4e0a12fd90f8cdfceb5367e1d399b68f6447910475e5607a7fc1d514c15d3f4c

MODEL
-----
LinearRegression

Target:
QSSI_SCORE

Features:
AI_NORM
LEGAL_NORM
PQC_NORM
RES_NORM
CONFIDENCE_SCORE

CORE DERIVED ARTIFACTS
----------------------
predict.py:
363bfe5537d98fcdea9b7927c20e817f2f5d0ef1de29afa0882bbfd5859d3137

Prediction CSV:
b8f43a5079721465d7dfb869794925b2197778afa5fef722eeeda973b77db525

Prediction metadata:
459fc081d0e6b88c2123114004537c151c1629381db18a0a3e96351eb1b50ef6

IP / USAGE POLICY
-----------------
© 2026 Bidyut Mazumdar. All rights reserved.

Non-commercial research use is subject to the applicable
research-use notice and attribution requirements.

Commercial use requires explicit prior written permission/license.

SaaS use requires explicit prior written permission/license.

Royalty and commercial licensing terms are reserved for a
separate written agreement.

INTEGRITY
---------
Source modification: NO
Source extraction: NO
Rank repair: NO
Tie resolution: NO
NO-RES anomaly modification: NO

This bundle is a derived reproducible publication artifact and
does not replace or modify the authoritative source archive.
