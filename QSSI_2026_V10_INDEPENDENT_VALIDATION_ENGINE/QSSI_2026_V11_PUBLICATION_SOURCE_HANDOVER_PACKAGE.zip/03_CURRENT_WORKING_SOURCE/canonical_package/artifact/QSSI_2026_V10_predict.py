#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
================================================================================
QSSI 2026 V10 — REPRODUCIBLE PREDICTION ENGINE
================================================================================

Artifact:
    QSSI_2026_V10_predict.py

Author:
    Bidyut Mazumdar

Role:
    Independent Research Scholar

Founder:
    FAIR+D Canon™ India 2025

ORCID:
    0009-0007-5615-3558

Canonical DOI:
    10.5281/zenodo.17302169

PURPOSE
-------
This script is a DERIVED prediction artifact.

It reads the authoritative QSSI 2026 V10 dataset directly from the
authoritative ZIP archive, validates cryptographic identity, trains the
locked regression model, and generates a separate prediction dataset.

AUTHORITATIVE SOURCE POLICY
---------------------------
The authoritative ZIP and authoritative CSV are READ-ONLY.

This script MUST NOT:
    - modify the authoritative ZIP
    - extract files into the authoritative source directory
    - overwrite the authoritative CSV
    - repair stored ranks
    - recalculate or overwrite stored ranks
    - resolve the preserved NO-RES tie anomaly
    - alter authoritative source values

PREDICTION MODEL
----------------
Problem type:
    Regression

Target:
    QSSI_SCORE

Locked features:
    AI_NORM
    LEGAL_NORM
    PQC_NORM
    RES_NORM
    CONFIDENCE_SCORE

Model:
    LinearRegression

DATA-LEAKAGE POLICY
-------------------
The following fields are NOT predictors:

    QSSI_RANK
    QSSI_NO_RES_RANK
    QSSI_TIER
    ORIGINAL_TIER
    LODO_TIER
    TIER_CHANGED
    RANK_ENTROPY
    RANK_CRITIC
    RANK_PCA

OUTPUT STATUS
-------------
All prediction outputs produced by this script are DERIVED analytical
artifacts and are NOT authoritative replacements for the source dataset.

INTELLECTUAL PROPERTY / COPYRIGHT
---------------------------------
Copyright © 2026 Bidyut Mazumdar. All rights reserved.

The mathematical formulations, computational models, architectures,
methodologies, software, source code, documentation, metadata structures,
and associated intellectual property embodied in this artifact are
proprietary unless a separate written license states otherwise.

Research and scholarly examination may be permitted for non-commercial
purposes subject to attribution and preservation of this notice.

Commercial exploitation, SaaS deployment, commercial redistribution,
commercial licensing, derivative commercial development, resale,
enterprise deployment, or incorporation into a commercial product or
service requires explicit prior written permission and a separate
written license from the rights holder.

No implied commercial license is granted by publication, archival
availability, DOI assignment, repository access, or possession of a copy.

Attribution:
    Bidyut Mazumdar
    ORCID: 0009-0007-5615-3558
    FAIR+D Canon™ India 2025

================================================================================
"""

from pathlib import Path
import hashlib
import io
import json
import zipfile
import sys

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression


# ==============================================================================
# CONFIGURATION
# ==============================================================================

AUTHOR = "Bidyut Mazumdar"
ORCID = "0009-0007-5615-3558"
DOI = "10.5281/zenodo.17302169"
PROJECT = "QSSI 2026 V10"
FOUNDER = "FAIR+D Canon™ India 2025"

ARCHIVE_NAME = "QSSI_2026_CLEAN_WORLD_RELEASE_ARCHIVE.zip"
DATASET_MEMBER = "QSSI_2026_MASTER_STAGE10B.csv"

EXPECTED_ZIP_SHA256 = (
    "57b264dab75ad5722e2b647ff46852bae0f5a9d239e9377e990fb3cf0b559e20"
)

EXPECTED_CSV_SHA256 = (
    "4e0a12fd90f8cdfceb5367e1d399b68f6447910475e5607a7fc1d514c15d3f4c"
)

TARGET = "QSSI_SCORE"

FEATURES = [
    "AI_NORM",
    "LEGAL_NORM",
    "PQC_NORM",
    "RES_NORM",
    "CONFIDENCE_SCORE",
]

REFERENCE_FIELDS = [
    "QSSI_RANK",
    "QSSI_NO_RES_RANK",
]

EXCLUDED_FIELDS = [
    "QSSI_RANK",
    "QSSI_NO_RES_RANK",
    "QSSI_TIER",
    "ORIGINAL_TIER",
    "LODO_TIER",
    "TIER_CHANGED",
    "RANK_ENTROPY",
    "RANK_CRITIC",
    "RANK_PCA",
]


# ==============================================================================
# HASH HELPERS
# ==============================================================================

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()

    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)

    return h.hexdigest()


# ==============================================================================
# ARCHIVE DISCOVERY
# ==============================================================================

def locate_archive() -> Path:

    candidates = [
        Path("/content/drive/MyDrive/QSSI 2026™")
        / ARCHIVE_NAME,

        Path.cwd() / ARCHIVE_NAME,
    ]

    for candidate in candidates:
        if candidate.exists():
            return candidate

    raise FileNotFoundError(
        "Authoritative QSSI archive could not be located."
    )


# ==============================================================================
# AUTHORITATIVE DATA LOADING
# ==============================================================================

def load_authoritative_dataframe():

    archive = locate_archive()

    actual_zip_sha = sha256_file(archive)

    if actual_zip_sha != EXPECTED_ZIP_SHA256:
        raise RuntimeError(
            "AUTHORITATIVE ZIP HASH MISMATCH.\n"
            f"Expected: {EXPECTED_ZIP_SHA256}\n"
            f"Actual:   {actual_zip_sha}"
        )

    with zipfile.ZipFile(archive, "r") as z:

        bad_crc = z.testzip()

        if bad_crc is not None:
            raise RuntimeError(
                f"ZIP CRC integrity failure: {bad_crc}"
            )

        if DATASET_MEMBER not in z.namelist():
            raise FileNotFoundError(
                f"Dataset member not found: {DATASET_MEMBER}"
            )

        raw_csv = z.read(DATASET_MEMBER)

    actual_csv_sha = sha256_bytes(raw_csv)

    if actual_csv_sha != EXPECTED_CSV_SHA256:
        raise RuntimeError(
            "AUTHORITATIVE CSV HASH MISMATCH.\n"
            f"Expected: {EXPECTED_CSV_SHA256}\n"
            f"Actual:   {actual_csv_sha}"
        )

    df = pd.read_csv(io.BytesIO(raw_csv))

    if len(df) != 195:
        raise RuntimeError(
            f"Unexpected dataset row count: {len(df)}"
        )

    if len(df.columns) != 36:
        raise RuntimeError(
            f"Unexpected dataset column count: {len(df.columns)}"
        )

    required = FEATURES + [TARGET] + REFERENCE_FIELDS

    missing = [c for c in required if c not in df.columns]

    if missing:
        raise RuntimeError(
            f"Required fields missing: {missing}"
        )

    return df, archive, actual_zip_sha, actual_csv_sha


# ==============================================================================
# MODEL VALIDATION
# ==============================================================================

def validate_model_fields(df):

    for col in FEATURES + [TARGET]:

        values = pd.to_numeric(
            df[col],
            errors="coerce"
        )

        if values.isna().any():
            raise RuntimeError(
                f"Non-numeric or missing values detected: {col}"
            )

        if not np.isfinite(values).all():
            raise RuntimeError(
                f"Non-finite values detected: {col}"
            )

    leakage = set(FEATURES) & set(EXCLUDED_FIELDS)

    if leakage:
        raise RuntimeError(
            f"DATA LEAKAGE DETECTED: {sorted(leakage)}"
        )


# ==============================================================================
# PREDICTION ENGINE
# ==============================================================================

def generate_predictions(df):

    X = df[FEATURES].astype(float)
    y = df[TARGET].astype(float)

    model = LinearRegression()

    model.fit(X, y)

    predicted = model.predict(X)

    output = df.copy()

    # --------------------------------------------------------------------------
    # DERIVED PREDICTION FIELDS
    # --------------------------------------------------------------------------

    output["QSSI_PREDICTED_SCORE"] = predicted

    output["QSSI_PREDICTION_DELTA"] = (
        output["QSSI_PREDICTED_SCORE"]
        - output["QSSI_SCORE"]
    )

    output["QSSI_PREDICTION_ABS_ERROR"] = (
        output["QSSI_PREDICTION_DELTA"].abs()
    )

    # --------------------------------------------------------------------------
    # DERIVED PREDICTED RANK
    #
    # IMPORTANT:
    # This is a NEW DERIVED ranking field.
    # It does NOT overwrite QSSI_RANK or QSSI_NO_RES_RANK.
    #
    # "first" provides deterministic ordering for equal predicted scores
    # according to current dataframe order.
    # --------------------------------------------------------------------------

    output["QSSI_PREDICTED_RANK"] = (
        output["QSSI_PREDICTED_SCORE"]
        .rank(
            ascending=False,
            method="first"
        )
        .astype(int)
    )

    # --------------------------------------------------------------------------
    # MODEL METADATA
    # --------------------------------------------------------------------------

    model_metadata = {
        "model": "LinearRegression",
        "target": TARGET,
        "features": FEATURES,
        "n_rows": int(len(output)),
        "intercept": float(model.intercept_),
        "coefficients": {
            feature: float(coef)
            for feature, coef in zip(FEATURES, model.coef_)
        },
        "prediction_min": float(np.min(predicted)),
        "prediction_max": float(np.max(predicted)),
        "prediction_mean": float(np.mean(predicted)),
        "prediction_std": float(np.std(predicted)),
    }

    return output, model_metadata


# ==============================================================================
# MAIN
# ==============================================================================

def main():

    print("=" * 80)
    print("QSSI 2026 V10 — PREDICTION ENGINE")
    print("=" * 80)

    df, archive, zip_sha, csv_sha = load_authoritative_dataframe()

    print("[PASS] Authoritative ZIP identity verified.")
    print("[PASS] Authoritative CSV identity verified.")
    print("[PASS] ZIP CRC integrity verified.")
    print("[PASS] Dataset loaded directly from ZIP.")
    print("[PASS] No ZIP extraction performed.")

    validate_model_fields(df)

    print("[PASS] Prediction feature validation completed.")
    print("[PASS] Data-leakage exclusion verified.")

    output, model_metadata = generate_predictions(df)

    print("[PASS] LinearRegression fitted.")
    print("[PASS] Derived predictions generated.")

    # --------------------------------------------------------------------------
    # DERIVED OUTPUT DIRECTORY
    # --------------------------------------------------------------------------

    output_dir = archive.parent / "QSSI_V10_PREDICTION_OUTPUT"
    output_dir.mkdir(parents=True, exist_ok=True)

    prediction_csv = (
        output_dir /
        "QSSI_2026_V10_PREDICTIONS.csv"
    )

    metadata_json = (
        output_dir /
        "QSSI_2026_V10_PREDICTION_METADATA.json"
    )

    output.to_csv(
        prediction_csv,
        index=False
    )

    metadata = {
        "project": PROJECT,
        "artifact": "QSSI_2026_V10_predict.py",
        "author": AUTHOR,
        "orcid": ORCID,
        "doi": DOI,
        "founder": FOUNDER,
        "source_archive": archive.name,
        "source_dataset_member": DATASET_MEMBER,
        "source_zip_sha256": zip_sha,
        "source_csv_sha256": csv_sha,
        "source_is_read_only": True,
        "source_modified": False,
        "source_extracted": False,
        "rank_repair": False,
        "tie_resolution": False,
        "target": TARGET,
        "features": FEATURES,
        "excluded_predictors": EXCLUDED_FIELDS,
        "model": model_metadata,
        "derived_prediction_output": prediction_csv.name,
        "output_is_authoritative": False,
        "copyright": (
            "© 2026 Bidyut Mazumdar. All rights reserved."
        ),
        "license_policy": (
            "Non-commercial scholarly research use may be permitted "
            "with attribution. Commercial exploitation, SaaS deployment, "
            "commercial redistribution, commercial derivative development "
            "or commercial incorporation requires explicit prior written "
            "permission and a separate written license."
        ),
    }

    with open(
        metadata_json,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            metadata,
            f,
            indent=2,
            ensure_ascii=False
        )

    # --------------------------------------------------------------------------
    # SOURCE IMMUTABILITY RECHECK
    # --------------------------------------------------------------------------

    final_zip_sha = sha256_file(archive)

    if final_zip_sha != EXPECTED_ZIP_SHA256:
        raise RuntimeError(
            "CRITICAL: Authoritative ZIP changed."
        )

    print("[PASS] Derived prediction CSV written.")
    print("[PASS] Derived metadata written.")
    print("[PASS] Authoritative ZIP SHA-256 unchanged.")
    print("[PASS] Source remains READ-ONLY.")

    print("-" * 80)
    print("DERIVED OUTPUT")
    print("-" * 80)
    print("Prediction CSV :", prediction_csv)
    print("Metadata JSON  :", metadata_json)

    print("=" * 80)
    print("PREDICTION ENGINE COMPLETE")
    print("=" * 80)


if __name__ == "__main__":
    main()
