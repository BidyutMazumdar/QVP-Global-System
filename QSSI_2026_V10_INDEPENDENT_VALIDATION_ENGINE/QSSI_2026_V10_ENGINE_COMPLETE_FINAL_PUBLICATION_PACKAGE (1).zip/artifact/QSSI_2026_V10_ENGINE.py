
print('QSSI 2026 Index Builder')
