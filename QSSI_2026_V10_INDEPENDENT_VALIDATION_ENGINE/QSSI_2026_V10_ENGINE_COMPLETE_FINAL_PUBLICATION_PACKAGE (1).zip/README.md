# QSSI 2026 V10 Engine Final Publication Release Bundle

## Executive Summary

This package preserves the authoritative engine source extracted from the official
QSSI_2026_ELITE_RESEARCH_PACKAGE_FINAL.zip archive.

This release is a source-preservation publication package and does not modify,
extend, replace, or reinterpret the archived implementation.

## Canonical Engine

- File: artifact/QSSI_2026_V10_ENGINE.py
- SHA-256: 9bdd8469af9be0e930dbc1edb6c41ceed59cb53262a7a628ec6abde322087333

## DOI

10.5281/zenodo.17302169

## ORCID

https://orcid.org/0009-0007-5615-3558

## Author

Bidyut Mazumdar
Independent Research Scholar
Founder, FAIR+D Canon™ India (2025)

## Integrity

This package preserves the archived source exactly as extracted.

## Licensing

Research and educational use only.
Commercial use, SaaS deployment, redistribution, derivative development,
and monetization require explicit prior written permission from the author.

Copyright © 2026 Bidyut Mazumdar. All rights reserved.
